//
//  NSObject+AnalysisData.m
//  Analysis
//
//  Created by lsh726 on 2017/12/18.
//  Copyright © 2017年 liusonghong. All rights reserved.
//

#import "NSObject+AnalysisData.h"
#import <objc/runtime.h>

@implementation NSObject (AnalysisData)

//解析对象字典数据
+ (id)analysisObj:(NSDictionary *)dic {
    id model = [[self alloc] init];
    NSArray *propertyArray = [self getProperty];
    for (NSString *obj in propertyArray) {
        id value = [dic valueForKey:obj];
        if ([value isKindOfClass:[NSDictionary class]]) {
            [self analysisObj:value];
        } else if ([value isKindOfClass:[NSArray class]]) {
            Class c = NSClassFromString(obj);
            if (c) [model setValue:[c analysisArray:value] forKey:obj];
        } else {
            [model setValue:value forKey:obj];
        }
    }
    return model;
}


//解析对象数组数据
+ (id)analysisArray:(NSArray *)dataArray {
    NSMutableArray *modelArray = [NSMutableArray array];
    NSAssert(dataArray.count != 0, @"数据源空");
    for (id values in dataArray) {
        if ([values isKindOfClass:[NSArray class]]) {
            [self analysisArray:values];//递归
        } else {
            [modelArray addObject:[self analysisObj:values]];
        }
    }
    return modelArray;
}


//获取属性列表
+ (NSArray *)getProperty{
    NSMutableArray *array = [NSMutableArray array];
    unsigned count = 0;
    objc_property_t *p = class_copyPropertyList(self, &count);
    for (NSInteger i = 0; i < count ; i ++) {
        const char *property_char = property_getName(p[i]);
        NSString *property_objc = [NSString stringWithUTF8String:property_char];
        [array addObject:property_objc];
    }
    free(p);
    return [NSArray arrayWithArray:array];
}

@end
